
# ⏱️ Chrome Extension: Productivity Time Tracker

## 📌 Task 4 - Full Stack Internship @ CodTech

This Chrome Extension tracks the time you spend on different websites and classifies them as productive or unproductive. The data can be shown in a popup and optionally stored in a backend for analytics.

---

## 🔧 Features

- Real-time tracking of active tab
- Local storage of time spent per site
- Popup UI to display tracked time
- Optional Node.js + MongoDB backend
- Easy to extend with a dashboard

---

## 🧪 How It Works

1. Background script detects active tabs and URLs.
2. Time is stored locally using `chrome.storage.local`.
3. A simple popup shows usage stats.
4. Data can optionally be posted to a backend server.

---

## 🚀 Run Extension Locally

1. Open Chrome → Extensions → Enable **Developer Mode**
2. Click **Load Unpacked** and select `extension/` folder

---

## 🌐 Backend Setup (Optional)

```bash
cd server
npm install express mongoose
node server.js
```

Make sure MongoDB is running.

---

## 📁 Folder Structure

```
chrome-time-tracker/
├── extension/
│   ├── manifest.json
│   ├── background.js
│   ├── popup.html
│   ├── popup.js
│   └── style.css
├── server/
│   ├── server.js
│   └── models/Activity.js
```

---

## 👨‍💻 Author

- Your Name
