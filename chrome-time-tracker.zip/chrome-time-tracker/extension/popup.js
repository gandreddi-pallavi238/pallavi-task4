
chrome.storage.local.get(null, (data) => {
  const stats = document.getElementById('stats');
  stats.innerHTML = Object.entries(data).map(([site, time]) => 
    `<p>${site}: ${Math.round(time)} sec</p>`).join('');
});
