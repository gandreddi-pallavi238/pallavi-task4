
const mongoose = require('mongoose');

const ActivitySchema = new mongoose.Schema({
  site: String,
  time: Number,
});

module.exports = mongoose.model('Activity', ActivitySchema);
