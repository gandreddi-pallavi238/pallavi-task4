
const express = require('express');
const mongoose = require('mongoose');
const Activity = require('./models/Activity');
const app = express();

mongoose.connect('mongodb://localhost:27017/tracker');

app.use(express.json());

app.post('/track', async (req, res) => {
  const { site, time } = req.body;
  await Activity.findOneAndUpdate(
    { site },
    { $inc: { time } },
    { upsert: true }
  );
  res.sendStatus(200);
});

app.listen(3002, () => console.log('Server on port 3002'));
